<template>
    <div>
        <footer class="footer-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="footer-item-outer">
                            <h4 class="title">
                                যোগাযোগ করুন
                            </h4>
                            <ul class="footer-list">
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="tel:+8801797950360">
                                        <i class="fas fa-phone-alt"></i>
                                        +880 1797 950 360
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="tel:+8801828165194">
                                        <i class="fas fa-phone-alt"></i>
                                        +880 1828 165 194
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="mailto:support@quickteamacademy.com">
                                        <i class="fas fa-envelope"></i>
                                        support@quickteamacademy.com
                                    </a>
                                </li>
                            </ul>
                            <ul class="footer-social-links">
                                <li class="footer-social-link-item">
                                    <a href="#">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li class="footer-social-link-item">
                                    <a href="#">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                                <li class="footer-social-link-item">
                                    <a href="#">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                </li>
                                <li class="footer-social-link-item">
                                    <a href="#">
                                        <i class="fab fa-youtube"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="footer-item-outer">
                            <h4 class="title">
                                অন্যান্য
                            </h4>
                            <ul class="footer-list">
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        আমাদের সম্পর্কে
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        যোগাযোগ করুন
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        প্রশ্নাবলী
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="footer-item-outer">
                            <h4 class="title">
                                নীতিমালা
                            </h4>
                            <ul class="footer-list">
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        Privacy Policy
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        Terms & Condition
                                    </a>
                                </li>
                                <li class="footer-list-item">
                                    <a class="footer-list-item-link" href="#">
                                        Certificate Verification
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="footer-item-outer">
                            <h4 class="title">
                                অফারের জন্য সাবস্ক্রাইব করুন
                            </h4>
                            <form action="" method="" class="subcribe-form form-group">
                                <input type="email" name="subcribe" class="form-control" placeholder="ইমেইল অ্যাড্রেস">
                                <button class="subcriber-btn">সাবস্ক্রাইব</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom-outer">
                    <p class="copyright-text">
                        © <a href="https://eurekabd-it.com" target="_blank">Eurekabd-it </a> All Right Reserved.
                    </p>
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
export default {
    name: "Footer"
}
</script>

<style scoped>

</style>
