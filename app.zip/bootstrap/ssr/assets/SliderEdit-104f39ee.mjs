import { unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderStyle, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./Layout-ef5f4fa4.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "SliderEdit",
  __ssrInlineRender: true,
  props: {
    slider: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      title: props.slider.title,
      sub_title: props.slider.sub_title,
      image: props.slider.image
    });
    const submit = () => {
      form.post(route("update.slider", props.slider.id), {
        forceFormData: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Slider Edit</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("slider-show"),
              class: "btn btn-sm btn-primary float-end",
              style: { "margin-top": "-35px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Slider`);
                } else {
                  return [
                    createTextVNode("Slider")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="row"${_scopeId}><div class="col-md-3"${_scopeId}></div><div class="col-md-6"${_scopeId}><form action="" method="post" enctype="multipart/form-data"${_scopeId}><div class="form-group"${_scopeId}><label for="title"${_scopeId}>Title</label><textarea class="form-control" rows="8" name="title" placeholder="Enter Short Description"${_scopeId}>${ssrInterpolate(unref(form).title)}</textarea>`);
            if (unref(form).errors.title) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="sub_title"${_scopeId}>Sub Title</label><textarea class="form-control" rows="8" name="sub_title" placeholder="Enter Long Description"${_scopeId}>${ssrInterpolate(unref(form).sub_title)}</textarea>`);
            if (unref(form).errors.sub_title) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.sub_title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="image"${_scopeId}>Image</label><input type="file" name="image" class="form-control"${_scopeId}><img${ssrRenderAttr("src", "/slider/" + unref(form).image)} style="${ssrRenderStyle({ "height": "200px", "width": "400px" })}" alt="slider image"${_scopeId}>`);
            if (unref(form).errors.image) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.image)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-success"])}"${_scopeId}>Submit</button></form></div><div class="col-md-3"${_scopeId}></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Slider Edit"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("slider-show"),
                          class: "btn btn-sm btn-primary float-end",
                          style: { "margin-top": "-35px" }
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Slider")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-3" }),
                          createVNode("div", { class: "col-md-6" }, [
                            createVNode("form", {
                              action: "",
                              onSubmit: withModifiers(submit, ["prevent"]),
                              method: "post",
                              enctype: "multipart/form-data"
                            }, [
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "title" }, "Title"),
                                withDirectives(createVNode("textarea", {
                                  class: "form-control",
                                  rows: "8",
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  name: "title",
                                  placeholder: "Enter Short Description"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).title]
                                ]),
                                unref(form).errors.title ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "sub_title" }, "Sub Title"),
                                withDirectives(createVNode("textarea", {
                                  class: "form-control",
                                  rows: "8",
                                  "onUpdate:modelValue": ($event) => unref(form).sub_title = $event,
                                  name: "sub_title",
                                  placeholder: "Enter Long Description"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).sub_title]
                                ]),
                                unref(form).errors.sub_title ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.sub_title), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "image" }, "Image"),
                                createVNode("input", {
                                  type: "file",
                                  name: "image",
                                  class: "form-control",
                                  onInput: ($event) => unref(form).image = $event.target.files[0]
                                }, null, 40, ["onInput"]),
                                createVNode("img", {
                                  src: "/slider/" + unref(form).image,
                                  style: { "height": "200px", "width": "400px" },
                                  alt: "slider image"
                                }, null, 8, ["src"]),
                                unref(form).errors.image ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.image), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("button", {
                                type: "submit",
                                class: ["btn btn-success", { "opacity-25": unref(form).processing }],
                                disabled: unref(form).processing
                              }, "Submit", 10, ["disabled"])
                            ], 40, ["onSubmit"])
                          ]),
                          createVNode("div", { class: "col-md-3" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/SliderEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
