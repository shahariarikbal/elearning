import { unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./Layout-ef5f4fa4.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "ServiceAdd",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      title: "",
      image: "",
      description: ""
    });
    const submit = () => {
      form.post(route("store.services"), {
        forceFormData: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Service Create</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("services"),
              class: "btn btn-sm btn-primary float-end",
              style: { "margin-top": "-35px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Services`);
                } else {
                  return [
                    createTextVNode("Services")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="row"${_scopeId}><div class="col-md-3"${_scopeId}></div><div class="col-md-6"${_scopeId}><form action="" method="post" enctype="multipart/form-data"${_scopeId}><div class="form-group"${_scopeId}><label for="title"${_scopeId}>Title</label><input type="text" name="title"${ssrRenderAttr("value", unref(form).title)} class="form-control" placeholder="Enter service title"${_scopeId}>`);
            if (unref(form).errors.title) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="description"${_scopeId}>Short Description</label><textarea class="form-control" rows="8" name="description" placeholder="Enter Short description"${_scopeId}>${ssrInterpolate(unref(form).description)}</textarea>`);
            if (unref(form).errors.description) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="image"${_scopeId}>Image</label><input type="file" name="image" class="form-control"${_scopeId}>`);
            if (unref(form).errors.image) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.image)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-success"])}"${_scopeId}>Submit</button></form></div><div class="col-md-3"${_scopeId}></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Service Create"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("services"),
                          class: "btn btn-sm btn-primary float-end",
                          style: { "margin-top": "-35px" }
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Services")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-3" }),
                          createVNode("div", { class: "col-md-6" }, [
                            createVNode("form", {
                              action: "",
                              onSubmit: withModifiers(submit, ["prevent"]),
                              method: "post",
                              enctype: "multipart/form-data"
                            }, [
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "title" }, "Title"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "title",
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  class: "form-control",
                                  placeholder: "Enter service title"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).title]
                                ]),
                                unref(form).errors.title ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "description" }, "Short Description"),
                                withDirectives(createVNode("textarea", {
                                  class: "form-control",
                                  rows: "8",
                                  "onUpdate:modelValue": ($event) => unref(form).description = $event,
                                  name: "description",
                                  placeholder: "Enter Short description"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).description]
                                ]),
                                unref(form).errors.description ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.description), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "image" }, "Image"),
                                createVNode("input", {
                                  type: "file",
                                  name: "image",
                                  class: "form-control",
                                  onInput: ($event) => unref(form).image = $event.target.files[0]
                                }, null, 40, ["onInput"]),
                                unref(form).errors.image ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.image), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("button", {
                                type: "submit",
                                class: ["btn btn-success", { "opacity-25": unref(form).processing }],
                                disabled: unref(form).processing
                              }, "Submit", 10, ["disabled"])
                            ], 40, ["onSubmit"])
                          ]),
                          createVNode("div", { class: "col-md-3" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/ServiceAdd.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
