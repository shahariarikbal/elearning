import { withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderComponent } from "vue/server-renderer";
import { a as _sfc_main$1 } from "./AuthenticatedLayout-eed99007.mjs";
const _sfc_main = {
  __name: "Sidebar",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><nav class="sidebar sidebar-offcanvas" id="sidebar"><ul class="nav"><li class="nav-item nav-profile"><a href="#" class="nav-link"><div class="nav-profile-image"><img${ssrRenderAttr("src", "/Backend/assets/images/faces/face1.jpg")} alt="profile"><span class="login-status online"></span></div><div class="nav-profile-text d-flex flex-column"><span class="font-weight-bold mb-2">${ssrInterpolate(_ctx.$page.props.auth.user.name)}</span><span class="text-secondary text-small">Owner</span></div><i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i></a></li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: _ctx.route("dashboard")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Dashboard</span><i class="mdi mdi-home menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Dashboard"),
              createVNode("i", { class: "mdi mdi-home menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: _ctx.route("services")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Services</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Services"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: _ctx.route("course-list")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Courses</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Courses"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: _ctx.route("trainer-list")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Trainers</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Trainers"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: _ctx.route("enroll-list")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Enroll</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Enroll"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: "frontend-slider"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Slider</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Slider"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="nav-item">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        class: "nav-link",
        href: "settings"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="menu-title"${_scopeId}>Settings</span><i class="mdi mdi-contacts menu-icon"${_scopeId}></i>`);
          } else {
            return [
              createVNode("span", { class: "menu-title" }, "Settings"),
              createVNode("i", { class: "mdi mdi-contacts menu-icon" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></nav></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/Backend/Sidebar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
