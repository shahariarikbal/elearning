import { unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "UserList",
  __ssrInlineRender: true,
  props: {
    enrolls: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const form = useForm({});
    function enrollDelete(id) {
      if (confirm("Are you sure you want to Delete")) {
        form.delete(route("delete.enroll", id));
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Enroll List</h4><table class="table table-striped"${_scopeId}><thead${_scopeId}><tr${_scopeId}><th${_scopeId}> SL </th><th${_scopeId}> Image </th><th${_scopeId}> Name </th><th${_scopeId}> Phone </th><th${_scopeId}> Email </th><th${_scopeId}> Course Name </th><th${_scopeId}> Course Type </th><th${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.enrolls, (enroll, index) => {
              _push2(`<tr${_scopeId}><td class="py-1"${_scopeId}>${ssrInterpolate(index + 1)}</td><td${_scopeId}><img${ssrRenderAttr("src", "/avatar/" + enroll.user.avatar)} height="100" width="100"${_scopeId}></td><td${_scopeId}>${ssrInterpolate(enroll.user.full_name)}</td><td${_scopeId}>${ssrInterpolate(enroll.user.phone)}</td><td${_scopeId}>${ssrInterpolate(enroll.user.email)}</td><td${_scopeId}>${ssrInterpolate(enroll.course.title)}</td><td style="${ssrRenderStyle({ "text-transform": "capitalize" })}"${_scopeId}>${ssrInterpolate(enroll.course.type)}</td><td${_scopeId}><button type="button" class="btn btn-sm btn-danger" style="${ssrRenderStyle({ "margin-left": "15px" })}"${_scopeId}><i class="mdi mdi-delete"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Enroll List"),
                        createVNode("table", { class: "table table-striped" }, [
                          createVNode("thead", null, [
                            createVNode("tr", null, [
                              createVNode("th", null, " SL "),
                              createVNode("th", null, " Image "),
                              createVNode("th", null, " Name "),
                              createVNode("th", null, " Phone "),
                              createVNode("th", null, " Email "),
                              createVNode("th", null, " Course Name "),
                              createVNode("th", null, " Course Type "),
                              createVNode("th", null, " Action ")
                            ])
                          ]),
                          createVNode("tbody", null, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.enrolls, (enroll, index) => {
                              return openBlock(), createBlock("tr", null, [
                                createVNode("td", { class: "py-1" }, toDisplayString(index + 1), 1),
                                createVNode("td", null, [
                                  createVNode("img", {
                                    src: "/avatar/" + enroll.user.avatar,
                                    height: "100",
                                    width: "100"
                                  }, null, 8, ["src"])
                                ]),
                                createVNode("td", null, toDisplayString(enroll.user.full_name), 1),
                                createVNode("td", null, toDisplayString(enroll.user.phone), 1),
                                createVNode("td", null, toDisplayString(enroll.user.email), 1),
                                createVNode("td", null, toDisplayString(enroll.course.title), 1),
                                createVNode("td", { style: { "text-transform": "capitalize" } }, toDisplayString(enroll.course.type), 1),
                                createVNode("td", null, [
                                  createVNode("button", {
                                    type: "button",
                                    onClick: ($event) => enrollDelete(enroll.id),
                                    class: "btn btn-sm btn-danger",
                                    style: { "margin-left": "15px" }
                                  }, [
                                    createVNode("i", { class: "mdi mdi-delete" })
                                  ], 8, ["onClick"])
                                ])
                              ]);
                            }), 256))
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/UserList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
