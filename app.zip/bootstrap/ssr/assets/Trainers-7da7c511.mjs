import { unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Trainers",
  __ssrInlineRender: true,
  props: {
    trainers: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const form = useForm({});
    function destroy(id) {
      if (confirm("Are you sure you want to Delete")) {
        form.delete(route("delete.trainers", id));
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Trainer List</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("add-trainers"),
              class: "btn btn-sm btn-primary float-end"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Add Trainer`);
                } else {
                  return [
                    createTextVNode(" Add Trainer")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<table class="table table-striped"${_scopeId}><thead${_scopeId}><tr${_scopeId}><th${_scopeId}> SL </th><th${_scopeId}> Image </th><th${_scopeId}> Name </th><th${_scopeId}> Email </th><th${_scopeId}> Phone </th><th${_scopeId}> Designation | Expertise </th><th${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.trainers, (trainer, index) => {
              _push2(`<tr${_scopeId}><td class="py-1"${_scopeId}>${ssrInterpolate(index + 1)}</td><td${_scopeId}><img${ssrRenderAttr("src", "/trainer/" + trainer.avatar)} height="100" width="100"${_scopeId}></td><td${_scopeId}>${ssrInterpolate(trainer.name)}</td><td${_scopeId}>${ssrInterpolate(trainer.email)}</td><td${_scopeId}>${ssrInterpolate(trainer.phone)}</td><td${_scopeId}>${ssrInterpolate(trainer.designation_expertise)}</td><td${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                href: "/trainer/edit/" + trainer.id,
                class: "btn btn-sm btn-primary"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<i class="mdi mdi-pencil"${_scopeId2}></i>`);
                  } else {
                    return [
                      createVNode("i", { class: "mdi mdi-pencil" })
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<button type="button" class="btn btn-sm btn-danger" style="${ssrRenderStyle({ "margin-left": "15px" })}"${_scopeId}><i class="mdi mdi-delete"${_scopeId}></i></button></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Trainer List"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("add-trainers"),
                          class: "btn btn-sm btn-primary float-end"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Add Trainer")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("table", { class: "table table-striped" }, [
                          createVNode("thead", null, [
                            createVNode("tr", null, [
                              createVNode("th", null, " SL "),
                              createVNode("th", null, " Image "),
                              createVNode("th", null, " Name "),
                              createVNode("th", null, " Email "),
                              createVNode("th", null, " Phone "),
                              createVNode("th", null, " Designation | Expertise "),
                              createVNode("th", null, " Action ")
                            ])
                          ]),
                          createVNode("tbody", null, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.trainers, (trainer, index) => {
                              return openBlock(), createBlock("tr", null, [
                                createVNode("td", { class: "py-1" }, toDisplayString(index + 1), 1),
                                createVNode("td", null, [
                                  createVNode("img", {
                                    src: "/trainer/" + trainer.avatar,
                                    height: "100",
                                    width: "100"
                                  }, null, 8, ["src"])
                                ]),
                                createVNode("td", null, toDisplayString(trainer.name), 1),
                                createVNode("td", null, toDisplayString(trainer.email), 1),
                                createVNode("td", null, toDisplayString(trainer.phone), 1),
                                createVNode("td", null, toDisplayString(trainer.designation_expertise), 1),
                                createVNode("td", null, [
                                  createVNode(_sfc_main$3, {
                                    href: "/trainer/edit/" + trainer.id,
                                    class: "btn btn-sm btn-primary"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("i", { class: "mdi mdi-pencil" })
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]),
                                  createVNode("button", {
                                    type: "button",
                                    onClick: ($event) => destroy(trainer.id),
                                    class: "btn btn-sm btn-danger",
                                    style: { "margin-left": "15px" }
                                  }, [
                                    createVNode("i", { class: "mdi mdi-delete" })
                                  ], 8, ["onClick"])
                                ])
                              ]);
                            }), 256))
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Trainers.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
