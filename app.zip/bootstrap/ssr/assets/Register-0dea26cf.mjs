import { L as Layout, F as Footer, N as NavLink } from "./Footer-18bed89c.mjs";
import { resolveComponent, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "@inertiajs/vue3";
const _sfc_main = {
  layout: Layout,
  components: { Footer, NavLink }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NavLink = resolveComponent("NavLink");
  _push(`<div${ssrRenderAttrs(_attrs)}><main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">Student Registration</h1><ul class="banner-item"><li>`);
  _push(ssrRenderComponent(_component_NavLink, { href: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
      } else {
        return [
          createVNode("i", { class: "fas fa-home" }),
          createTextVNode(" Home ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="active">`);
  _push(ssrRenderComponent(_component_NavLink, { href: "/user/register" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Registration `);
      } else {
        return [
          createTextVNode(" Registration ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div></div></section><section class="login-section"><div class="container"><div class="login-form-wrapper"><form action="" method="" class="registration-form form-group"><div class="title">Student Registration</div><div class="row"><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="text" class="form-control" name="first_name" value="" placeholder="First Name"></div></div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="text" class="form-control" name="last_name" value="" placeholder="Last Name"></div></div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-envelope"></span><input type="email" class="form-control" name="email" value="" placeholder="Email"></div></div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-phone-alt"></span><input type="text" name="phone" class="form-control" value="" placeholder="Phone"></div></div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control" name="password" placeholder="Password"><i id="icon" class="fas fa-eye"></i></div></div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password"><i id="icon" class="fas fa-eye"></i></div></div><div class="col-md-12"><div class="input-field-wrapper"><span class="fas fa-camera"></span><input type="file" name="avatar" class="form-control" accept="image/*"></div></div></div><p style="${ssrRenderStyle({ "font-size": "13px", "font-weight": "600", "color": "red" })}">Use image sort-name and Minimum file size of 100 KB</p><div class="submit-btn-outer"><button type="submit" class="submit-btn-inner"> Sign up </button></div>`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/user/login",
    class: "sign-up-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Sign In`);
      } else {
        return [
          createTextVNode("Sign In")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</form></div></div></section></main></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/Register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Register = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Register as default
};
