import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { useSSRContext } from "vue";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  name: "Footer"
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}><footer class="footer-section"><div class="container"><div class="row"><div class="col-lg-3 col-md-6 col-sm-6"><div class="footer-item-outer"><h4 class="title"> যোগাযোগ করুন </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link"${ssrRenderAttr("href", "tel:" + _ctx.$page.props.setting.allSetting.phone)}><i class="fas fa-phone-alt"></i> ${ssrInterpolate(_ctx.$page.props.setting.allSetting.phone)}</a></li><li class="footer-list-item"><a class="footer-list-item-link"${ssrRenderAttr("href", "mailto:" + _ctx.$page.props.setting.allSetting.email)}><i class="fas fa-envelope"></i> ${ssrInterpolate(_ctx.$page.props.setting.allSetting.email)}</a></li></ul><ul class="footer-social-links"><li class="footer-social-link-item"><a${ssrRenderAttr("href", _ctx.$page.props.setting.allSetting.facebook)} target="_blank"><i class="fab fa-facebook-f"></i></a></li><li class="footer-social-link-item"><a${ssrRenderAttr("href", _ctx.$page.props.setting.allSetting.twitter)} target="_blank"><i class="fab fa-twitter"></i></a></li><li class="footer-social-link-item"><a${ssrRenderAttr("href", _ctx.$page.props.setting.allSetting.instagram)} target="_blank"><i class="fab fa-instagram"></i></a></li><li class="footer-social-link-item"><a${ssrRenderAttr("href", _ctx.$page.props.setting.allSetting.youtube)} target="_blank"><i class="fab fa-youtube"></i></a></li></ul></div></div><div class="col-lg-2 col-md-6 col-sm-6"><div class="footer-item-outer"><h4 class="title"> অন্যান্য </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link" href="#"> আমাদের সম্পর্কে </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> যোগাযোগ করুন </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> প্রশ্নাবলী </a></li></ul></div></div><div class="col-lg-2 col-md-6 col-sm-6"><div class="footer-item-outer"><h4 class="title"> নীতিমালা </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Privacy Policy </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Terms &amp; Condition </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Certificate Verification </a></li></ul></div></div><div class="col-lg-5 col-md-6 col-sm-6"><div class="footer-item-outer"><h4 class="title"> অফারের জন্য সাবস্ক্রাইব করুন </h4><form action="" method="" class="subcribe-form form-group"><input type="email" name="subcribe" class="form-control" placeholder="ইমেইল অ্যাড্রেস"><button class="subcriber-btn">সাবস্ক্রাইব</button></form></div></div></div><div class="footer-bottom-outer"><p class="copyright-text"> © Pixency-IT All Right Reserved. </p></div></div></footer></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Footer as F
};
