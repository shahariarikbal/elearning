import { computed, resolveComponent, withCtx, createVNode, createTextVNode, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { L as Layout, N as NavLink } from "./Layout-ef5f4fa4.mjs";
import { F as Footer } from "./Footer-3c0e37ac.mjs";
import { usePage, useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Details",
  __ssrInlineRender: true,
  props: {
    course: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const props = __props;
    const user = computed(() => usePage().props.user.userId);
    const form = useForm({
      message: "",
      user_id: user,
      course_id: props.course.id
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = resolveComponent("Head");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_Head, { title: "Welcome" }, null, _parent));
      _push(ssrRenderComponent(Layout, null, null, _parent));
      _push(`<main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">Course Details</h1><ul class="banner-item"><li>`);
      _push(ssrRenderComponent(NavLink, { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
          } else {
            return [
              createVNode("i", { class: "fas fa-home" }),
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="active"><a href="#"> single </a></li></ul></div></div></section><section class="course-details-section"><div class="container"><div class="row"><div class="col-md-8"><div class="course-details-wrapper"><div class="course-details-video"><iframe width="100%" height="315"${ssrRenderAttr("src", __props.course.video_url)} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div><div class="course-details-outer"><h3 class="title">${ssrInterpolate(__props.course.title)} কোর্সটি থেকে যা শিখবেন.. </h3><p class="description">${ssrInterpolate(__props.course.long_description)}</p></div><div class="course-review-outer"><h4 class="title"> শিক্ষার্থীদের মতামত </h4><!--[-->`);
      ssrRenderList(__props.course.comments, (comment) => {
        _push(`<div class="course-review-item"><img${ssrRenderAttr("src", "/frontend/images/user-default.png")} class="user-image"><div class="course-review-content"><h5 class="author-name">${ssrInterpolate(comment.user.first_name)} <span class="review-date"></span></h5><p class="review-message">${ssrInterpolate(comment.message)}</p></div></div>`);
      });
      _push(`<!--]--></div>`);
      if (_ctx.$page.props.user.userId) {
        _push(`<div><form method="post" class="review-form form-group"><label for="message">Enter your message here:</label><textarea class="form-control" name="message" rows="5">${ssrInterpolate(unref(form).message)}</textarea><input type="hidden" name="user_id" class="form-control"${ssrRenderAttr("value", unref(form).user_id)}><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-sm"])}">Submit</button></form></div>`);
      } else {
        _push(`<div class="">`);
        _push(ssrRenderComponent(NavLink, {
          href: "/user/login",
          class: "nav-item-link login-logout"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` লগ ইন / সাইন আপ `);
            } else {
              return [
                createTextVNode(" লগ ইন / সাইন আপ ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div></div><div class="col-md-4"><div class="course-details-sidebar-wrapper"><div class="course-price-outer">`);
      if (__props.course.discount_price != null) {
        _push(`<span class="price">${ssrInterpolate(__props.course.discount_price)} BDT</span>`);
      } else {
        _push(`<span class="price">${ssrInterpolate(__props.course.real_price)} BDT</span>`);
      }
      _push(`</div><div class="course-instructor-outer"><div class="course-instructor-image"><img${ssrRenderAttr("src", "/trainer/" + __props.course.trainer.avatar)} alt="trainer" class="img-fluid rounded-circle"></div><div class="course-instructor-name"><a href="#" class="instructor-name">${ssrInterpolate(__props.course.trainer.name)}</a><p class="instructor-des">${ssrInterpolate(__props.course.trainer.designation_expertise)}</p></div></div><ul><li><strong>কোর্সটি করছেনঃ</strong> <span>১৩,৮১৯ শিক্ষার্থী</span></li><li><strong>ভিডিও সংখ্যাঃ</strong> <span>${ssrInterpolate(__props.course.lesson)}</span></li><li><strong>সময় লাগবেঃ</strong> <span>${ssrInterpolate(__props.course.duration)}</span></li></ul>`);
      _push(ssrRenderComponent(NavLink, {
        href: "/user/register/" + __props.course.id + "/" + __props.course.slug,
        class: "course-details-btn-inner"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`কোর্সটি শুরু করুন`);
          } else {
            return [
              createTextVNode("কোর্সটি শুরু করুন")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></section></main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Courses/Details.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
