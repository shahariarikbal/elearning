import { unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, vModelSelect, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./Layout-ef5f4fa4.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "CourseAdd",
  __ssrInlineRender: true,
  props: {
    trainers: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const form = useForm({
      title: "",
      trainer_id: "",
      short_description: "",
      long_description: "",
      type: "",
      real_price: "",
      discount_price: "",
      lesson: "",
      duration: "",
      video_url: "",
      image: ""
    });
    const submit = () => {
      form.post(route("store.courses"), {
        forceFormData: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Course Create</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("course-list"),
              class: "btn btn-sm btn-primary float-end",
              style: { "margin-top": "-35px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Courses`);
                } else {
                  return [
                    createTextVNode("Courses")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="row"${_scopeId}><div class="col-md-3"${_scopeId}></div><div class="col-md-6"${_scopeId}><form action="" method="post" enctype="multipart/form-data"${_scopeId}><div class="form-group"${_scopeId}><label for="title"${_scopeId}>Title</label><input type="text" name="title"${ssrRenderAttr("value", unref(form).title)} class="form-control" placeholder="Enter course title"${_scopeId}>`);
            if (unref(form).errors.title) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.title)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="short_description"${_scopeId}>Short Description</label><textarea class="form-control" rows="8" name="short_description" placeholder="Enter Short Description"${_scopeId}>${ssrInterpolate(unref(form).short_description)}</textarea>`);
            if (unref(form).errors.short_description) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.short_description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="long_description"${_scopeId}>Long Description</label><textarea class="form-control" rows="8" name="long_description" placeholder="Enter Long Description"${_scopeId}>${ssrInterpolate(unref(form).long_description)}</textarea>`);
            if (unref(form).errors.long_description) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.long_description)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="type"${_scopeId}>Course Type</label><select class="form-control" name="type"${_scopeId}><option value="online"${_scopeId}>Online</option><option value="offline"${_scopeId}>Offline</option><option value="record"${_scopeId}>Record</option><option value="free"${_scopeId}>Free</option></select>`);
            if (unref(form).errors.type) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.type)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="trainer_id"${_scopeId}>Trainer</label><select class="form-control" name="trainer_id"${_scopeId}><!--[-->`);
            ssrRenderList(__props.trainers, (trainer) => {
              _push2(`<option${ssrRenderAttr("value", trainer.id)}${_scopeId}>${ssrInterpolate(trainer.name)}</option>`);
            });
            _push2(`<!--]--></select>`);
            if (unref(form).errors.trainer_id) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.trainer_id)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="real_price"${_scopeId}>Real Price</label><input type="number" name="real_price"${ssrRenderAttr("value", unref(form).real_price)} class="form-control" placeholder="Enter course real_price"${_scopeId}>`);
            if (unref(form).errors.real_price) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.real_price)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="discount_price"${_scopeId}>Discount Price</label><input type="number" name="discount_price"${ssrRenderAttr("value", unref(form).discount_price)} class="form-control" placeholder="Enter course discount_price"${_scopeId}>`);
            if (unref(form).errors.discount_price) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.discount_price)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="lesson"${_scopeId}>Number of Lesson</label><input type="number" name="lesson"${ssrRenderAttr("value", unref(form).lesson)} class="form-control" placeholder="Enter course lesson"${_scopeId}>`);
            if (unref(form).errors.lesson) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.lesson)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="duration"${_scopeId}>Course Duration</label><input type="text" name="duration"${ssrRenderAttr("value", unref(form).duration)} class="form-control" placeholder="Enter course duration"${_scopeId}>`);
            if (unref(form).errors.duration) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.duration)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="video_url"${_scopeId}>Video URL</label><input type="text" name="video_url"${ssrRenderAttr("value", unref(form).video_url)} class="form-control" placeholder="Enter course video url"${_scopeId}>`);
            if (unref(form).errors.video_url) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.video_url)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="image"${_scopeId}>Image</label><input type="file" name="image" class="form-control"${_scopeId}>`);
            if (unref(form).errors.image) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.image)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-success"])}"${_scopeId}>Submit</button></form></div><div class="col-md-3"${_scopeId}></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Course Create"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("course-list"),
                          class: "btn btn-sm btn-primary float-end",
                          style: { "margin-top": "-35px" }
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Courses")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-3" }),
                          createVNode("div", { class: "col-md-6" }, [
                            createVNode("form", {
                              action: "",
                              onSubmit: withModifiers(submit, ["prevent"]),
                              method: "post",
                              enctype: "multipart/form-data"
                            }, [
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "title" }, "Title"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "title",
                                  "onUpdate:modelValue": ($event) => unref(form).title = $event,
                                  class: "form-control",
                                  placeholder: "Enter course title"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).title]
                                ]),
                                unref(form).errors.title ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.title), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "short_description" }, "Short Description"),
                                withDirectives(createVNode("textarea", {
                                  class: "form-control",
                                  rows: "8",
                                  "onUpdate:modelValue": ($event) => unref(form).short_description = $event,
                                  name: "short_description",
                                  placeholder: "Enter Short Description"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).short_description]
                                ]),
                                unref(form).errors.short_description ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.short_description), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "long_description" }, "Long Description"),
                                withDirectives(createVNode("textarea", {
                                  class: "form-control",
                                  rows: "8",
                                  "onUpdate:modelValue": ($event) => unref(form).long_description = $event,
                                  name: "long_description",
                                  placeholder: "Enter Long Description"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).long_description]
                                ]),
                                unref(form).errors.long_description ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.long_description), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "type" }, "Course Type"),
                                withDirectives(createVNode("select", {
                                  class: "form-control",
                                  "onUpdate:modelValue": ($event) => unref(form).type = $event,
                                  name: "type"
                                }, [
                                  createVNode("option", { value: "online" }, "Online"),
                                  createVNode("option", { value: "offline" }, "Offline"),
                                  createVNode("option", { value: "record" }, "Record"),
                                  createVNode("option", { value: "free" }, "Free")
                                ], 8, ["onUpdate:modelValue"]), [
                                  [vModelSelect, unref(form).type]
                                ]),
                                unref(form).errors.type ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.type), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "trainer_id" }, "Trainer"),
                                withDirectives(createVNode("select", {
                                  class: "form-control",
                                  "onUpdate:modelValue": ($event) => unref(form).trainer_id = $event,
                                  name: "trainer_id"
                                }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(__props.trainers, (trainer) => {
                                    return openBlock(), createBlock("option", {
                                      value: trainer.id,
                                      key: trainer.id
                                    }, toDisplayString(trainer.name), 9, ["value"]);
                                  }), 128))
                                ], 8, ["onUpdate:modelValue"]), [
                                  [vModelSelect, unref(form).trainer_id]
                                ]),
                                unref(form).errors.trainer_id ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.trainer_id), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "real_price" }, "Real Price"),
                                withDirectives(createVNode("input", {
                                  type: "number",
                                  name: "real_price",
                                  "onUpdate:modelValue": ($event) => unref(form).real_price = $event,
                                  class: "form-control",
                                  placeholder: "Enter course real_price"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).real_price]
                                ]),
                                unref(form).errors.real_price ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.real_price), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "discount_price" }, "Discount Price"),
                                withDirectives(createVNode("input", {
                                  type: "number",
                                  name: "discount_price",
                                  "onUpdate:modelValue": ($event) => unref(form).discount_price = $event,
                                  class: "form-control",
                                  placeholder: "Enter course discount_price"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).discount_price]
                                ]),
                                unref(form).errors.discount_price ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.discount_price), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "lesson" }, "Number of Lesson"),
                                withDirectives(createVNode("input", {
                                  type: "number",
                                  name: "lesson",
                                  "onUpdate:modelValue": ($event) => unref(form).lesson = $event,
                                  class: "form-control",
                                  placeholder: "Enter course lesson"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).lesson]
                                ]),
                                unref(form).errors.lesson ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.lesson), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "duration" }, "Course Duration"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "duration",
                                  "onUpdate:modelValue": ($event) => unref(form).duration = $event,
                                  class: "form-control",
                                  placeholder: "Enter course duration"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).duration]
                                ]),
                                unref(form).errors.duration ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.duration), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "video_url" }, "Video URL"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "video_url",
                                  "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
                                  class: "form-control",
                                  placeholder: "Enter course video url"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).video_url]
                                ]),
                                unref(form).errors.video_url ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.video_url), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "image" }, "Image"),
                                createVNode("input", {
                                  type: "file",
                                  name: "image",
                                  class: "form-control",
                                  onInput: ($event) => unref(form).image = $event.target.files[0]
                                }, null, 40, ["onInput"]),
                                unref(form).errors.image ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.image), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("button", {
                                type: "submit",
                                class: ["btn btn-success", { "opacity-25": unref(form).processing }],
                                disabled: unref(form).processing
                              }, "Submit", 10, ["disabled"])
                            ], 40, ["onSubmit"])
                          ]),
                          createVNode("div", { class: "col-md-3" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/CourseAdd.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
