import { unref, withCtx, createTextVNode, createVNode, withModifiers, openBlock, createBlock, toDisplayString, createCommentVNode, withDirectives, vModelText, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./Layout-ef5f4fa4.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "SettingEdit",
  __ssrInlineRender: true,
  props: {
    setting: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      logo: props.setting.logo,
      phone: props.setting.phone,
      email: props.setting.email,
      youtube: props.setting.youtube,
      facebook: props.setting.facebook,
      twitter: props.setting.twitter,
      instagram: props.setting.instagram
    });
    const submit = () => {
      form.post(route("update.setting", props.setting.id), {
        forceFormData: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Setting Edit</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("setting-show"),
              class: "btn btn-sm btn-primary float-end",
              style: { "margin-top": "-35px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Setting`);
                } else {
                  return [
                    createTextVNode("Setting")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="row"${_scopeId}><div class="col-md-3"${_scopeId}></div><div class="col-md-6"${_scopeId}><form action="" method="post" enctype="multipart/form-data"${_scopeId}><div class="form-group"${_scopeId}><label for="logo"${_scopeId}>logo</label><input type="file" name="logo" class="form-control"${_scopeId}><img${ssrRenderAttr("src", "/setting/" + unref(form).logo)} style="${ssrRenderStyle({ "height": "80px", "width": "150px" })}" alt="logo"${_scopeId}>`);
            if (unref(form).errors.logo) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.logo)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="phone"${_scopeId}>Phone</label><input type="text" name="phone"${ssrRenderAttr("value", unref(form).phone)} class="form-control" placeholder="Enter phone"${_scopeId}>`);
            if (unref(form).errors.phone) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.phone)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="email"${_scopeId}>Email</label><input type="email" name="email"${ssrRenderAttr("value", unref(form).email)} class="form-control" placeholder="Enter email"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="youtube"${_scopeId}>YouTube Channel Link</label><input type="text" name="youtube"${ssrRenderAttr("value", unref(form).youtube)} class="form-control" placeholder="Enter youtube channel link"${_scopeId}>`);
            if (unref(form).errors.youtube) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.youtube)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="facebook"${_scopeId}>Facebook page Link</label><input type="text" name="facebook"${ssrRenderAttr("value", unref(form).facebook)} class="form-control" placeholder="Enter Facebook page link"${_scopeId}>`);
            if (unref(form).errors.facebook) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.facebook)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="twitter"${_scopeId}>Twitter Link</label><input type="text" name="twitter"${ssrRenderAttr("value", unref(form).twitter)} class="form-control" placeholder="Enter twitter page link"${_scopeId}>`);
            if (unref(form).errors.twitter) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.twitter)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="instagram"${_scopeId}>Instagram Link</label><input type="text" name="instagram"${ssrRenderAttr("value", unref(form).instagram)} class="form-control" placeholder="Enter instagram page link"${_scopeId}>`);
            if (unref(form).errors.instagram) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.instagram)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-success"])}"${_scopeId}>Submit</button></form></div><div class="col-md-3"${_scopeId}></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Setting Edit"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("setting-show"),
                          class: "btn btn-sm btn-primary float-end",
                          style: { "margin-top": "-35px" }
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Setting")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-3" }),
                          createVNode("div", { class: "col-md-6" }, [
                            createVNode("form", {
                              action: "",
                              onSubmit: withModifiers(submit, ["prevent"]),
                              method: "post",
                              enctype: "multipart/form-data"
                            }, [
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "logo" }, "logo"),
                                createVNode("input", {
                                  type: "file",
                                  name: "logo",
                                  class: "form-control",
                                  onInput: ($event) => unref(form).logo = $event.target.files[0]
                                }, null, 40, ["onInput"]),
                                createVNode("img", {
                                  src: "/setting/" + unref(form).logo,
                                  style: { "height": "80px", "width": "150px" },
                                  alt: "logo"
                                }, null, 8, ["src"]),
                                unref(form).errors.logo ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.logo), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "phone" }, "Phone"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "phone",
                                  "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                  class: "form-control",
                                  placeholder: "Enter phone"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).phone]
                                ]),
                                unref(form).errors.phone ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.phone), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "email" }, "Email"),
                                withDirectives(createVNode("input", {
                                  type: "email",
                                  name: "email",
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  class: "form-control",
                                  placeholder: "Enter email"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).email]
                                ]),
                                unref(form).errors.email ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "youtube" }, "YouTube Channel Link"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "youtube",
                                  "onUpdate:modelValue": ($event) => unref(form).youtube = $event,
                                  class: "form-control",
                                  placeholder: "Enter youtube channel link"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).youtube]
                                ]),
                                unref(form).errors.youtube ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.youtube), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "facebook" }, "Facebook page Link"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "facebook",
                                  "onUpdate:modelValue": ($event) => unref(form).facebook = $event,
                                  class: "form-control",
                                  placeholder: "Enter Facebook page link"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).facebook]
                                ]),
                                unref(form).errors.facebook ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.facebook), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "twitter" }, "Twitter Link"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "twitter",
                                  "onUpdate:modelValue": ($event) => unref(form).twitter = $event,
                                  class: "form-control",
                                  placeholder: "Enter twitter page link"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).twitter]
                                ]),
                                unref(form).errors.twitter ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.twitter), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "instagram" }, "Instagram Link"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "instagram",
                                  "onUpdate:modelValue": ($event) => unref(form).instagram = $event,
                                  class: "form-control",
                                  placeholder: "Enter instagram page link"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).instagram]
                                ]),
                                unref(form).errors.instagram ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.instagram), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("button", {
                                type: "submit",
                                class: ["btn btn-success", { "opacity-25": unref(form).processing }],
                                disabled: unref(form).processing
                              }, "Submit", 10, ["disabled"])
                            ], 40, ["onSubmit"])
                          ]),
                          createVNode("div", { class: "col-md-3" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/SettingEdit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
