import { resolveComponent, withCtx, createTextVNode, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from "vue/server-renderer";
import { L as Layout, N as NavLink } from "./Layout-ef5f4fa4.mjs";
import { F as Footer } from "./Footer-3c0e37ac.mjs";
import { useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Welcome",
  __ssrInlineRender: true,
  props: {
    slider: {
      type: Object,
      default: () => ({})
    },
    services: {
      type: Object,
      default: () => ({})
    },
    onlineCourses: {
      type: Object,
      default: () => ({})
    },
    offlineCourses: {
      type: Object,
      default: () => ({})
    },
    freeCourses: {
      type: Object,
      default: () => ({})
    },
    recordCourses: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    useForm({});
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = resolveComponent("Head");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Head, { title: "Welcome" }, null, _parent));
      _push(ssrRenderComponent(Layout, null, null, _parent));
      _push(`<main><section class="home-section"><div class="container"><div class="row align-items-center"><div class="col-md-6"><div class="home-sec-left-side-wrap"><h1 class="title">${ssrInterpolate(__props.slider.title)}</h1><p class="sub-title">${ssrInterpolate(__props.slider.sub_title)}</p><div class="home-sec-left-link-outer">`);
      _push(ssrRenderComponent(NavLink, {
        href: "/courses",
        class: "course-link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`কোর্সগুলো দেখুন`);
          } else {
            return [
              createTextVNode("কোর্সগুলো দেখুন")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(NavLink, {
        href: "/user/login",
        class: "login-link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`লগ ইন / সাইন আপ`);
          } else {
            return [
              createTextVNode("লগ ইন / সাইন আপ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="col-md-6"><div class="home-sec-right-side-wrap"><img${ssrRenderAttr("src", "/slider/" + __props.slider.image)}></div></div></div></div></section><section class="our-achievment-section"><div class="container"><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">অর্জন</span> সমূহ </h2></div><div class="row"><div class="col-lg-3 col-md-6 col-sm-12"><div class="achiement-item-wrap"><h4 class="count-number"> 10000 <span>+</span></h4><h6 class="name"> নিবন্ধিত শিক্ষার্থী </h6></div></div><div class="col-lg-3 col-md-6 col-sm-12"><div class="achiement-item-wrap"><h4 class="count-number"> 10 </h4><h6 class="name"> ট্রেইনার </h6></div></div><div class="col-lg-3 col-md-6 col-sm-12"><div class="achiement-item-wrap"><h4 class="count-number"> 15 </h4><h6 class="name"> মোট কোর্স </h6></div></div><div class="col-lg-3 col-md-6 col-sm-12"><div class="achiement-item-wrap"><h4 class="count-number"> 10000 <span>%</span></h4><h6 class="name"> সফল শিক্ষার্থী </h6></div></div></div></div></section><section class="about-us-section"><div class="container"><div class="section-title-outer"><h2 class="title"> কেন <span class="separate-color">আমরা </span> সেরা </h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.services, (service) => {
        _push(`<div class="col-lg-4 col-md-6 col-sm-12"><div class="about-item-wrap"><img${ssrRenderAttr("src", "/service/" + service.image)} class="image"><h4 class="title">${ssrInterpolate(service.title)}</h4><p class="text">${ssrInterpolate(service.description)}</p></div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="course-section"><div class="container"><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">অনলাইন কোর্স </span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.onlineCourses, (onlineCourse) => {
        _push(`<div class="col-lg-4 col-md-6 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + onlineCourse.id + "/" + onlineCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + onlineCourse.image)} alt="course image"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + onlineCourse.image,
                  alt: "course image"
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (onlineCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(onlineCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(onlineCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(onlineCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(onlineCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + onlineCourse.id + "/" + onlineCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(onlineCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(onlineCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(onlineCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="course-section" style="${ssrRenderStyle({ "background": "#EFF2F6" })}"><div class="container"><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">অফলাইন কোর্স </span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.offlineCourses, (offlineCourse) => {
        _push(`<div class="col-lg-4 col-md-6 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + offlineCourse.id + "/" + offlineCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + offlineCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + offlineCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (offlineCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(offlineCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(offlineCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(offlineCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(offlineCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + offlineCourse.id + "/" + offlineCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(offlineCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(offlineCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(offlineCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="course-section"><div class="container"><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">রেকর্ড কোর্স</span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.recordCourses, (recordCourse) => {
        _push(`<div class="col-lg-4 col-md-6 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + recordCourse.id + "/" + recordCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + recordCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + recordCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (recordCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(recordCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(recordCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(recordCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(recordCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + recordCourse.id + "/" + recordCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(recordCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(recordCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(recordCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section><section class="course-section" style="${ssrRenderStyle({ "background": "rgb(239, 242, 246)" })}"><div class="container"><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">ফ্রি কোর্স</span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.freeCourses, (freeCourse) => {
        _push(`<div class="col-lg-4 col-md-6 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + freeCourse.id + "/" + freeCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + freeCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + freeCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (freeCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(freeCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(freeCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(freeCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(freeCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + freeCourse.id + "/" + freeCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(freeCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(freeCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(freeCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section></main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
