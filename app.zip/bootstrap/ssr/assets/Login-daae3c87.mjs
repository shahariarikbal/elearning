import { withCtx, createVNode, createTextVNode, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr } from "vue/server-renderer";
import { L as Layout, N as NavLink } from "./Layout-ef5f4fa4.mjs";
import { F as Footer } from "./Footer-3c0e37ac.mjs";
import { useForm } from "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Login",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      email: "",
      password: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(Layout, null, null, _parent));
      _push(`<main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">Student Login</h1><ul class="banner-item"><li>`);
      _push(ssrRenderComponent(NavLink, { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
          } else {
            return [
              createVNode("i", { class: "fas fa-home" }),
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="active"><a href="#"> Login </a></li></ul></div></div></section><section class="login-section"><div class="container"><div class="login-form-wrapper"><form class="login-form form-group"><div class="title">Student Login</div><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="email" class="form-control"${ssrRenderAttr("value", unref(form).email)} name="email" placeholder="Email"></div><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control"${ssrRenderAttr("value", unref(form).password)} name="password" id="password" placeholder="Password"><i id="icon" class="fas fa-eye"></i></div><div class="submit-btn-outer"><button type="submit" class="submit-btn-inner"> Sign in </button></div></form></div></div></section></main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
