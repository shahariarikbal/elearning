import { Link } from "@inertiajs/vue3";
import { resolveComponent, mergeProps, withCtx, renderSlot, useSSRContext, createVNode, createTextVNode } from "vue";
import { ssrRenderComponent, ssrRenderSlot, ssrRenderAttrs, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main$3 = {
  name: "NavLink",
  components: {
    Link
  }
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Link = resolveComponent("Link");
  _push(ssrRenderComponent(_component_Link, mergeProps({ href: "/" }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
      } else {
        return [
          renderSlot(_ctx.$slots, "default")
        ];
      }
    }),
    _: 3
  }, _parent));
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/NavLink.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const NavLink = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$2 = {
  name: "Header",
  components: {
    NavLink
  }
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NavLink = resolveComponent("NavLink");
  _push(`<div${ssrRenderAttrs(_attrs)}><header class="header-section"><nav class="nav-items-wrapper">`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/",
    class: "navbar-brand"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img class="brand"${ssrRenderAttr("src", "/frontend/images/logo.png")} alt="Logo"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            class: "brand",
            src: "/frontend/images/logo.png",
            alt: "Logo"
          }, null, 8, ["src"])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<div class="nav-toggle-btn"><div class="btn-inner"></div></div><ul class="nav-list"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/",
    class: "nav-item-link active"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fas fa-home"${_scopeId}></i> হোম `);
      } else {
        return [
          createVNode("i", { class: "fas fa-home" }),
          createTextVNode(" হোম ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/courses",
    class: "nav-item-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fab fa-discourse"${_scopeId}></i> কোর্স সমূহ `);
      } else {
        return [
          createVNode("i", { class: "fab fa-discourse" }),
          createTextVNode(" কোর্স সমূহ ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item"><a href="#" class="nav-item-link"><i class="fas fa-video"></i> লাইভ ব্যাচ </a></li><li class="nav-item"><a href="#" class="nav-item-link"><i class="fas fa-fire"></i> অফার </a></li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/user/login",
    class: "nav-item-link login-logout"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` লগ ইন / সাইন আপ `);
      } else {
        return [
          createTextVNode(" লগ ইন / সাইন আপ ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></nav></header></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/Header.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Header = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$1 = {
  components: {
    Header
  },
  name: "Layout"
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Header = resolveComponent("Header");
  _push(`<!--[-->`);
  _push(ssrRenderComponent(_component_Header, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`<!--]-->`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/Layout.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Layout = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {
  name: "Footer"
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(_attrs)}><footer class="footer-section"><div class="container"><div class="row"><div class="col-md-3"><div class="footer-item-outer"><h4 class="title"> যোগাযোগ করুন </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link" href="tel:+8801797950360"><i class="fas fa-phone-alt"></i> +880 1797 950 360 </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="tel:+8801828165194"><i class="fas fa-phone-alt"></i> +880 1828 165 194 </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="mailto:support@quickteamacademy.com"><i class="fas fa-envelope"></i> support@quickteamacademy.com </a></li></ul><ul class="footer-social-links"><li class="footer-social-link-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li><li class="footer-social-link-item"><a href="#"><i class="fab fa-twitter"></i></a></li><li class="footer-social-link-item"><a href="#"><i class="fab fa-instagram"></i></a></li><li class="footer-social-link-item"><a href="#"><i class="fab fa-youtube"></i></a></li></ul></div></div><div class="col-md-2"><div class="footer-item-outer"><h4 class="title"> অন্যান্য </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link" href="#"> আমাদের সম্পর্কে </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> যোগাযোগ করুন </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> প্রশ্নাবলী </a></li></ul></div></div><div class="col-md-2"><div class="footer-item-outer"><h4 class="title"> নীতিমালা </h4><ul class="footer-list"><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Privacy Policy </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Terms &amp; Condition </a></li><li class="footer-list-item"><a class="footer-list-item-link" href="#"> Certificate Verification </a></li></ul></div></div><div class="col-md-5"><div class="footer-item-outer"><h4 class="title"> অফারের জন্য সাবস্ক্রাইব করুন </h4><form action="" method="" class="subcribe-form form-group"><input type="email" name="subcribe" class="form-control" placeholder="ইমেইল অ্যাড্রেস"><button class="subcriber-btn">সাবস্ক্রাইব</button></form></div></div></div><div class="footer-bottom-outer"><p class="copyright-text"> © <a href="https://eurekabd-it.com" target="_blank">Eurekabd-it </a> All Right Reserved. </p></div></div></footer></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Shared/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Footer as F,
  Layout as L,
  NavLink as N
};
