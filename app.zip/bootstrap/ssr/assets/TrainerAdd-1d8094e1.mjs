import { unref, withCtx, createTextVNode, createVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$3 } from "./AuthenticatedLayout-eed99007.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./Layout-ef5f4fa4.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "TrainerAdd",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      name: "",
      email: "",
      phone: "",
      designation_expertise: "",
      avatar: ""
    });
    const submit = () => {
      form.post(route("store.trainers"), {
        forceFormData: true
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="main-panel"${_scopeId}><div class="col-lg-12 grid-margin stretch-card"${_scopeId}><div class="card"${_scopeId}><div class="card-body"${_scopeId}><h4 class="card-title"${_scopeId}>Trainer Create</h4>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              href: _ctx.route("trainer-list"),
              class: "btn btn-sm btn-primary float-end",
              style: { "margin-top": "-35px" }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Trainers`);
                } else {
                  return [
                    createTextVNode("Trainers")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="row"${_scopeId}><div class="col-md-3"${_scopeId}></div><div class="col-md-6"${_scopeId}><form action="" method="post" enctype="multipart/form-data"${_scopeId}><div class="form-group"${_scopeId}><label for="name"${_scopeId}>Name</label><input type="text" name="name"${ssrRenderAttr("value", unref(form).name)} class="form-control" placeholder="Enter course name"${_scopeId}>`);
            if (unref(form).errors.name) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.name)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="email"${_scopeId}>Email</label><input type="email" name="email"${ssrRenderAttr("value", unref(form).email)} class="form-control" placeholder="Enter Trainer&#39;s Email"${_scopeId}>`);
            if (unref(form).errors.email) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.email)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="phone"${_scopeId}>Phone</label><input type="text" name="phone"${ssrRenderAttr("value", unref(form).phone)} class="form-control" placeholder="Enter Trainer&#39;s Phone"${_scopeId}>`);
            if (unref(form).errors.phone) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.phone)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="designation_expertise"${_scopeId}>Designation | Expertise</label><input type="text" name="designation_expertise"${ssrRenderAttr("value", unref(form).designation_expertise)} class="form-control" placeholder="Enter Trainer&#39;s Designation or Expertise"${_scopeId}>`);
            if (unref(form).errors.designation_expertise) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.designation_expertise)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="form-group"${_scopeId}><label for="avatar"${_scopeId}>Image</label><input type="file" name="avatar" class="form-control"${_scopeId}>`);
            if (unref(form).errors.avatar) {
              _push2(`<div class="text-sm text-red-600"${_scopeId}>${ssrInterpolate(unref(form).errors.avatar)}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "btn btn-success"])}"${_scopeId}>Submit</button></form></div><div class="col-md-3"${_scopeId}></div></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "main-panel" }, [
                  createVNode("div", { class: "col-lg-12 grid-margin stretch-card" }, [
                    createVNode("div", { class: "card" }, [
                      createVNode("div", { class: "card-body" }, [
                        createVNode("h4", { class: "card-title" }, "Trainer Create"),
                        createVNode(_sfc_main$3, {
                          href: _ctx.route("trainer-list"),
                          class: "btn btn-sm btn-primary float-end",
                          style: { "margin-top": "-35px" }
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Trainers")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "row" }, [
                          createVNode("div", { class: "col-md-3" }),
                          createVNode("div", { class: "col-md-6" }, [
                            createVNode("form", {
                              action: "",
                              onSubmit: withModifiers(submit, ["prevent"]),
                              method: "post",
                              enctype: "multipart/form-data"
                            }, [
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "name" }, "Name"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "name",
                                  "onUpdate:modelValue": ($event) => unref(form).name = $event,
                                  class: "form-control",
                                  placeholder: "Enter course name"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).name]
                                ]),
                                unref(form).errors.name ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.name), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "email" }, "Email"),
                                withDirectives(createVNode("input", {
                                  type: "email",
                                  name: "email",
                                  "onUpdate:modelValue": ($event) => unref(form).email = $event,
                                  class: "form-control",
                                  placeholder: "Enter Trainer's Email"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).email]
                                ]),
                                unref(form).errors.email ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.email), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "phone" }, "Phone"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "phone",
                                  "onUpdate:modelValue": ($event) => unref(form).phone = $event,
                                  class: "form-control",
                                  placeholder: "Enter Trainer's Phone"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).phone]
                                ]),
                                unref(form).errors.phone ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.phone), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "designation_expertise" }, "Designation | Expertise"),
                                withDirectives(createVNode("input", {
                                  type: "text",
                                  name: "designation_expertise",
                                  "onUpdate:modelValue": ($event) => unref(form).designation_expertise = $event,
                                  class: "form-control",
                                  placeholder: "Enter Trainer's Designation or Expertise"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, unref(form).designation_expertise]
                                ]),
                                unref(form).errors.designation_expertise ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.designation_expertise), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("div", { class: "form-group" }, [
                                createVNode("label", { for: "avatar" }, "Image"),
                                createVNode("input", {
                                  type: "file",
                                  name: "avatar",
                                  class: "form-control",
                                  onInput: ($event) => unref(form).avatar = $event.target.files[0]
                                }, null, 40, ["onInput"]),
                                unref(form).errors.avatar ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "text-sm text-red-600"
                                }, toDisplayString(unref(form).errors.avatar), 1)) : createCommentVNode("", true)
                              ]),
                              createVNode("button", {
                                type: "submit",
                                class: ["btn btn-success", { "opacity-25": unref(form).processing }],
                                disabled: unref(form).processing
                              }, "Submit", 10, ["disabled"])
                            ], 40, ["onSubmit"])
                          ]),
                          createVNode("div", { class: "col-md-3" })
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/TrainerAdd.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
