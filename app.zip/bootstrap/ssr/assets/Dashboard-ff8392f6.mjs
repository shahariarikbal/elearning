import { unref, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-eed99007.mjs";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Sidebar-e586382f.mjs";
import "./ApplicationLogo-8b847249.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container-fluid page-body-wrapper"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, null, null, _parent2, _scopeId));
            _push2(`<div class="content-wrapper"${_scopeId}><div class="page-header"${_scopeId}><h3 class="page-title"${_scopeId}><span class="page-title-icon bg-gradient-primary text-white me-2"${_scopeId}><i class="mdi mdi-home"${_scopeId}></i></span> Dashboard </h3><nav aria-label="breadcrumb"${_scopeId}><ul class="breadcrumb"${_scopeId}><li class="breadcrumb-item active" aria-current="page"${_scopeId}><span${_scopeId}></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"${_scopeId}></i></li></ul></nav></div><div class="row"${_scopeId}><div class="col-md-4 stretch-card grid-margin"${_scopeId}><div class="card bg-gradient-danger card-img-holder text-white"${_scopeId}><div class="card-body"${_scopeId}><img${ssrRenderAttr("src", "Backend/assets/images/dashboard/circle.svg")} class="card-img-absolute" alt="circle-image"${_scopeId}><h4 class="font-weight-normal mb-3"${_scopeId}>Weekly Sales <i class="mdi mdi-chart-line mdi-24px float-right"${_scopeId}></i></h4><h2 class="mb-5"${_scopeId}>$ 15,0000</h2><h6 class="card-text"${_scopeId}>Increased by 60%</h6></div></div></div><div class="col-md-4 stretch-card grid-margin"${_scopeId}><div class="card bg-gradient-info card-img-holder text-white"${_scopeId}><div class="card-body"${_scopeId}><img${ssrRenderAttr("src", "Backend/assets/images/dashboard/circle.svg")} class="card-img-absolute" alt="circle-image"${_scopeId}><h4 class="font-weight-normal mb-3"${_scopeId}>Weekly Orders <i class="mdi mdi-bookmark-outline mdi-24px float-right"${_scopeId}></i></h4><h2 class="mb-5"${_scopeId}>45,6334</h2><h6 class="card-text"${_scopeId}>Decreased by 10%</h6></div></div></div><div class="col-md-4 stretch-card grid-margin"${_scopeId}><div class="card bg-gradient-success card-img-holder text-white"${_scopeId}><div class="card-body"${_scopeId}><img${ssrRenderAttr("src", "Backend/assets/images/dashboard/circle.svg")} class="card-img-absolute" alt="circle-image"${_scopeId}><h4 class="font-weight-normal mb-3"${_scopeId}>Visitors Online <i class="mdi mdi-diamond mdi-24px float-right"${_scopeId}></i></h4><h2 class="mb-5"${_scopeId}>95,5741</h2><h6 class="card-text"${_scopeId}>Increased by 5%</h6></div></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "container-fluid page-body-wrapper" }, [
                createVNode(_sfc_main$2),
                createVNode("div", { class: "content-wrapper" }, [
                  createVNode("div", { class: "page-header" }, [
                    createVNode("h3", { class: "page-title" }, [
                      createVNode("span", { class: "page-title-icon bg-gradient-primary text-white me-2" }, [
                        createVNode("i", { class: "mdi mdi-home" })
                      ]),
                      createTextVNode(" Dashboard ")
                    ]),
                    createVNode("nav", { "aria-label": "breadcrumb" }, [
                      createVNode("ul", { class: "breadcrumb" }, [
                        createVNode("li", {
                          class: "breadcrumb-item active",
                          "aria-current": "page"
                        }, [
                          createVNode("span"),
                          createTextVNode("Overview "),
                          createVNode("i", { class: "mdi mdi-alert-circle-outline icon-sm text-primary align-middle" })
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "row" }, [
                    createVNode("div", { class: "col-md-4 stretch-card grid-margin" }, [
                      createVNode("div", { class: "card bg-gradient-danger card-img-holder text-white" }, [
                        createVNode("div", { class: "card-body" }, [
                          createVNode("img", {
                            src: "Backend/assets/images/dashboard/circle.svg",
                            class: "card-img-absolute",
                            alt: "circle-image"
                          }, null, 8, ["src"]),
                          createVNode("h4", { class: "font-weight-normal mb-3" }, [
                            createTextVNode("Weekly Sales "),
                            createVNode("i", { class: "mdi mdi-chart-line mdi-24px float-right" })
                          ]),
                          createVNode("h2", { class: "mb-5" }, "$ 15,0000"),
                          createVNode("h6", { class: "card-text" }, "Increased by 60%")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "col-md-4 stretch-card grid-margin" }, [
                      createVNode("div", { class: "card bg-gradient-info card-img-holder text-white" }, [
                        createVNode("div", { class: "card-body" }, [
                          createVNode("img", {
                            src: "Backend/assets/images/dashboard/circle.svg",
                            class: "card-img-absolute",
                            alt: "circle-image"
                          }, null, 8, ["src"]),
                          createVNode("h4", { class: "font-weight-normal mb-3" }, [
                            createTextVNode("Weekly Orders "),
                            createVNode("i", { class: "mdi mdi-bookmark-outline mdi-24px float-right" })
                          ]),
                          createVNode("h2", { class: "mb-5" }, "45,6334"),
                          createVNode("h6", { class: "card-text" }, "Decreased by 10%")
                        ])
                      ])
                    ]),
                    createVNode("div", { class: "col-md-4 stretch-card grid-margin" }, [
                      createVNode("div", { class: "card bg-gradient-success card-img-holder text-white" }, [
                        createVNode("div", { class: "card-body" }, [
                          createVNode("img", {
                            src: "Backend/assets/images/dashboard/circle.svg",
                            class: "card-img-absolute",
                            alt: "circle-image"
                          }, null, 8, ["src"]),
                          createVNode("h4", { class: "font-weight-normal mb-3" }, [
                            createTextVNode("Visitors Online "),
                            createVNode("i", { class: "mdi mdi-diamond mdi-24px float-right" })
                          ]),
                          createVNode("h2", { class: "mb-5" }, "95,5741"),
                          createVNode("h6", { class: "card-text" }, "Increased by 5%")
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
