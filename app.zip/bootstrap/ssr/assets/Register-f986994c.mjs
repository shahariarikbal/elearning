import { unref, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderClass } from "vue/server-renderer";
import { L as Layout, N as NavLink } from "./Layout-ef5f4fa4.mjs";
import { useForm, Head } from "@inertiajs/vue3";
import { F as Footer } from "./Footer-3c0e37ac.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Register",
  __ssrInlineRender: true,
  props: {
    id: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      first_name: "",
      last_name: "",
      email: "",
      phone: "",
      avatar: "",
      password: "",
      password_confirmation: "",
      course_id: props.id
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(unref(Head), { title: "User Register" }, null, _parent));
      _push(ssrRenderComponent(Layout, null, null, _parent));
      _push(`<main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">Student Registration</h1><ul class="banner-item"><li>`);
      _push(ssrRenderComponent(NavLink, { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
          } else {
            return [
              createVNode("i", { class: "fas fa-home" }),
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="active">`);
      _push(ssrRenderComponent(NavLink, { href: "/user/register" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Registration `);
          } else {
            return [
              createTextVNode(" Registration ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div></div></section><section class="login-section"><div class="container"><div class="login-form-wrapper"><form method="post" class="registration-form form-group" enctype="multipart/form-data">`);
      if (_ctx.$page.props.flash.message) {
        _push(`<div class="alert alert-success alert-dismissible fade show" role="alert"><strong>Success!</strong> ${ssrInterpolate(_ctx.$page.props.flash.message)}. <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="title">Student Registration</div><div class="row"><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="text" class="form-control" name="first_name"${ssrRenderAttr("value", unref(form).first_name)} placeholder="First Name"></div>`);
      if (unref(form).errors.first_name) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.first_name)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="text" class="form-control" name="last_name"${ssrRenderAttr("value", unref(form).last_name)} placeholder="Last Name"></div>`);
      if (unref(form).errors.last_name) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.last_name)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-envelope"></span><input type="email" class="form-control" name="email"${ssrRenderAttr("value", unref(form).email)} placeholder="Email"></div>`);
      if (unref(form).errors.email) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.email)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-phone-alt"></span><input type="text" name="phone"${ssrRenderAttr("value", unref(form).phone)} class="form-control" placeholder="Phone"></div>`);
      if (unref(form).errors.phone) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.phone)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control"${ssrRenderAttr("value", unref(form).password)} name="password" placeholder="Password"><i id="icon" class="fas fa-eye"></i></div>`);
      if (unref(form).errors.password) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.password)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-6"><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control" name="password_confirmation"${ssrRenderAttr("value", unref(form).password_confirmation)} placeholder="Confirm Password"><i id="icon" class="fas fa-eye"></i></div>`);
      if (unref(form).errors.password_confirmation) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.password_confirmation)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="col-md-12"><div class="input-field-wrapper"><span class="fas fa-camera"></span><input type="file" name="avatar" class="form-control" accept="image/*"></div>`);
      if (unref(form).errors.avatar) {
        _push(`<div class="text-sm text-red-600">${ssrInterpolate(unref(form).errors.avatar)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><p style="${ssrRenderStyle({ "font-size": "13px", "font-weight": "600", "color": "red" })}">Use image sort-name and Minimum file size of 100 KB</p><div class="submit-btn-outer"><button type="submit"${ssrIncludeBooleanAttr(unref(form).processing) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-25": unref(form).processing }, "submit-btn-inner"])}"> Sign up </button></div>`);
      _push(ssrRenderComponent(NavLink, {
        href: "/user/login",
        class: "sign-up-link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sign In`);
          } else {
            return [
              createTextVNode("Sign In")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</form></div></div></section></main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/Register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
