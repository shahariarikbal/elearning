import { withCtx, createVNode, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { L as Layout, N as NavLink } from "./Layout-ef5f4fa4.mjs";
import { F as Footer } from "./Footer-3c0e37ac.mjs";
import "@inertiajs/vue3";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "CourseList",
  __ssrInlineRender: true,
  props: {
    onlineCourses: {
      type: Object,
      default: () => ({})
    },
    offlineCourses: {
      type: Object,
      default: () => ({})
    },
    freeCourses: {
      type: Object,
      default: () => ({})
    },
    recordCourses: {
      type: Object,
      default: () => ({})
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(Layout, null, null, _parent));
      _push(`<main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">All Course</h1><ul class="banner-item"><li>`);
      _push(ssrRenderComponent(NavLink, { href: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
          } else {
            return [
              createVNode("i", { class: "fas fa-home" }),
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="active"><a href="#"> Course </a></li></ul></div></div></section><section class="course-details-section"><div class="container"><div class="all-course-tab-wrapper"><div class="row"><div class="col-lg-4 col-md-12 col-sm-12"><div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical"><h2 class="all-course-button-title"> আমাদের কোর্স তালিকা </h2><button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true"> Online Course </button><button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false"> Offline Course </button><button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false"> Record Course </button><button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"> Free Course </button></div></div><div class="col-lg-8 col-md-12 col-sm-12"><div class="tab-content" id="v-pills-tabContent"><div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab"><section class="all-course-section"><div class=""><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">অনলাইন কোর্স</span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.onlineCourses, (onlineCourse) => {
        _push(`<div class="col-lg-6 col-md-12 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + onlineCourse.id + "/" + onlineCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + onlineCourse.image)} alt="course image"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + onlineCourse.image,
                  alt: "course image"
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (onlineCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(onlineCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(onlineCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(onlineCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(onlineCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + onlineCourse.id + "/" + onlineCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(onlineCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(onlineCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(onlineCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section></div><div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab"><section class="all-course-section"><div class=""><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">অফলাইন কোর্স </span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.offlineCourses, (offlineCourse) => {
        _push(`<div class="col-lg-6 col-md-12 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + offlineCourse.id + "/" + offlineCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + offlineCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + offlineCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (offlineCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(offlineCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(offlineCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(offlineCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(offlineCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + offlineCourse.id + "/" + offlineCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(offlineCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(offlineCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(offlineCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section></div><div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab"><section class="all-course-section"><div class=""><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">রেকর্ড কোর্স</span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.recordCourses, (recordCourse) => {
        _push(`<div class="col-lg-6 col-md-12 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + recordCourse.id + "/" + recordCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + recordCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + recordCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (recordCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(recordCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(recordCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(recordCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(recordCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + recordCourse.id + "/" + recordCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(recordCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(recordCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(recordCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section></div><div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab"><section class="all-course-section"><div class=""><div class="section-title-outer"><h2 class="title"> আমাদের <span class="separate-color">ফ্রি কোর্স</span></h2></div><div class="row"><!--[-->`);
      ssrRenderList(__props.freeCourses, (freeCourse) => {
        _push(`<div class="col-lg-6 col-md-12 col-sm-12"><div class="course-item-wrap">`);
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + freeCourse.id + "/" + freeCourse.slug,
          class: "course-item-image-outer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", "course/" + freeCourse.image)}${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: "course/" + freeCourse.image
                }, null, 8, ["src"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-item-content">`);
        if (freeCourse.discount_price != null) {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(freeCourse.discount_price)} ৳</span><del class="origin-price">${ssrInterpolate(freeCourse.real_price)} ৳</del></div>`);
        } else {
          _push(`<div class="course-price"><span class="discount-price">${ssrInterpolate(freeCourse.real_price)} ৳</span><del class="origin-price">${ssrInterpolate(freeCourse.discount_price)} ৳</del></div>`);
        }
        _push(ssrRenderComponent(NavLink, {
          href: "course/details/" + freeCourse.id + "/" + freeCourse.slug,
          class: "course-title"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(freeCourse.title)}`);
            } else {
              return [
                createTextVNode(toDisplayString(freeCourse.title), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="course-meta"><div class="meta-item course-lesson"><i class="far fa-file-alt"></i> ${ssrInterpolate(freeCourse.lesson)} Lessons </div><div class="meta-item course-students"><i class="far fa-user"></i> 300 Students </div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section></div></div></div></div></div></div></section></main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Courses/CourseList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
