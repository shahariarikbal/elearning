import { L as Layout, F as Footer, N as NavLink } from "./Footer-18bed89c.mjs";
import { resolveComponent, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "@inertiajs/vue3";
const _sfc_main = {
  layout: Layout,
  components: { Footer, NavLink }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NavLink = resolveComponent("NavLink");
  _push(`<div${ssrRenderAttrs(_attrs)}><main><section class="banner-section" style="${ssrRenderStyle({ "background-image": "url(/frontend/images/banner.jpg)" })}"><div class="container"><div class="col-md-12"><h1 class="banner-title">Student Login</h1><ul class="banner-item"><li>`);
  _push(ssrRenderComponent(_component_NavLink, { href: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fas fa-home"${_scopeId}></i> Home `);
      } else {
        return [
          createVNode("i", { class: "fas fa-home" }),
          createTextVNode(" Home ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="active"><a href="#"> Login </a></li></ul></div></div></section><section class="login-section"><div class="container"><div class="login-form-wrapper"><form action="" method="" class="login-form form-group"><div class="title">Student Login</div><div class="input-field-wrapper"><span class="fas fa-user"></span><input type="email" class="form-control" name="email" placeholder="Email"></div><div class="input-field-wrapper"><span class="fas fa-lock"></span><input type="password" class="form-control" name="password" id="password" placeholder="Password"><i id="icon" class="fas fa-eye"></i></div><a href="#" class="reset-password-link">Reset Password ?</a><div class="submit-btn-outer"><button type="submit" class="submit-btn-inner"> Sign in </button></div>`);
  _push(ssrRenderComponent(_component_NavLink, {
    href: "/user/register",
    class: "sign-up-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Sign Up`);
      } else {
        return [
          createTextVNode("Sign Up")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</form></div></div></section></main></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/User/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Login = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Login as default
};
